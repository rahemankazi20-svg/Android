package com.example.webview;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    WebView webview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       webview = findViewById(R.id.webview);

       webview.getSettings().setJavaScriptEnabled(true);
       webview.getSettings().setAllowContentAccess(true);
       webview.getSettings().setDomStorageEnabled(true);

       webview.loadUrl("https://www.google.com/");

       webview.setWebViewClient(new WebViewClient());

    }
}